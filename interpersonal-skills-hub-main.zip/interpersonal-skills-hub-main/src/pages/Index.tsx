
import React, { useEffect } from 'react';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import Hero from '@/components/sections/Hero';
import KeySkills from '@/components/sections/KeySkills';
import Importance from '@/components/sections/Importance';
import Resources from '@/components/sections/Resources';

const Index = () => {
  useEffect(() => {
    // Smooth scroll to section when hash changes
    const handleHashChange = () => {
      const { hash } = window.location;
      if (hash) {
        setTimeout(() => {
          const element = document.querySelector(hash);
          if (element) {
            window.scrollTo({
              top: element.getBoundingClientRect().top + window.pageYOffset - 100,
              behavior: 'smooth'
            });
          }
        }, 100);
      }
    };

    // Initial check for hash on page load
    if (window.location.hash) {
      handleHashChange();
    }

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        <Hero />
        <KeySkills />
        <Importance />
        <Resources />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
