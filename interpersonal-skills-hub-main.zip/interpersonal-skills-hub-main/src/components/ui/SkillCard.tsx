
import React from 'react';
import { cn } from '@/lib/utils';
import BlurredCard from './BlurredCard';
import AnimatedText from './AnimatedText';

interface SkillCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  delay?: number;
  className?: string;
}

const SkillCard: React.FC<SkillCardProps> = ({ 
  title, 
  description, 
  icon,
  delay = 0,
  className
}) => {
  return (
    <AnimatedText delay={delay} animation="slide-up">
      <BlurredCard 
        className={cn(
          'p-6 hover:shadow-md hover:translate-y-[-5px] transition-all duration-300',
          className
        )}
      >
        <div className="flex flex-col items-start gap-4">
          <div className="p-3 rounded-full bg-primary/10 text-primary">
            {icon}
          </div>
          <div>
            <div className="skill-chip mb-2">{title}</div>
            <p className="text-gray-700 leading-relaxed">{description}</p>
          </div>
        </div>
      </BlurredCard>
    </AnimatedText>
  );
};

export default SkillCard;
