
import React from 'react';
import { cn } from '@/lib/utils';

interface BlurredCardProps {
  children: React.ReactNode;
  className?: string;
  intensity?: 'light' | 'medium' | 'heavy';
}

const BlurredCard: React.FC<BlurredCardProps> = ({ 
  children, 
  className,
  intensity = 'medium'
}) => {
  const getIntensityClasses = () => {
    switch (intensity) {
      case 'light':
        return 'bg-white/40 backdrop-blur-sm';
      case 'heavy':
        return 'bg-white/80 backdrop-blur-xl';
      case 'medium':
      default:
        return 'bg-white/60 backdrop-blur-md';
    }
  };
  
  return (
    <div 
      className={cn(
        'rounded-2xl border border-white/20 shadow-sm transition-all duration-300',
        getIntensityClasses(),
        className
      )}
    >
      {children}
    </div>
  );
};

export default BlurredCard;
