
import React, { useState, useEffect } from 'react';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import AnimatedText from '@/components/ui/AnimatedText';
import BlurredCard from '@/components/ui/BlurredCard';

const Hero: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center pt-20 px-6 md:px-10">
      {/* Background Elements */}
      <div className="absolute inset-0 -z-10 overflow-hidden">
        <div className="absolute top-20 right-[10%] w-72 h-72 rounded-full bg-blue-200/30 filter blur-3xl animate-float"></div>
        <div className="absolute bottom-20 left-[5%] w-64 h-64 rounded-full bg-purple-200/20 filter blur-3xl animate-float" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-[40%] left-[30%] w-96 h-96 rounded-full bg-primary/10 filter blur-3xl animate-float" style={{ animationDelay: '1s' }}></div>
      </div>

      <div className="max-w-7xl mx-auto w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
              <div className="skill-chip mb-4">Master Interpersonal Communication</div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
                Elevate Your Interpersonal Skills
              </h1>
              <p className="text-lg text-gray-700 mb-8 max-w-lg">
                Discover the art of effective communication and relationship-building to succeed in both personal and professional settings.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button className="rounded-full group px-6 py-6 bg-primary hover:bg-primary/90 text-white">
                  Explore Skills
                  <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={18} />
                </Button>
                <Button variant="outline" className="rounded-full px-6 py-6">
                  Learn More
                </Button>
              </div>
            </div>
          </div>
          
          <div className="relative h-[500px] w-full">
            <AnimatedText 
              delay={300} 
              animation="scale-in" 
              className="absolute top-10 left-0 z-10 lg:left-10"
            >
              <BlurredCard className="p-6 w-64">
                <h3 className="text-lg font-semibold mb-2">Effective Communication</h3>
                <p className="text-gray-600">The foundation of strong relationships</p>
              </BlurredCard>
            </AnimatedText>
            
            <AnimatedText 
              delay={600} 
              animation="scale-in" 
              className="absolute top-1/3 right-0 lg:right-0 z-20"
            >
              <BlurredCard className="p-6 w-64">
                <h3 className="text-lg font-semibold mb-2">Emotional Intelligence</h3>
                <p className="text-gray-600">Understanding yourself and others</p>
              </BlurredCard>
            </AnimatedText>
            
            <AnimatedText 
              delay={900} 
              animation="scale-in" 
              className="absolute bottom-10 left-1/4 z-30"
            >
              <BlurredCard className="p-6 w-64">
                <h3 className="text-lg font-semibold mb-2">Conflict Resolution</h3>
                <p className="text-gray-600">Turn disagreements into opportunities</p>
              </BlurredCard>
            </AnimatedText>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
