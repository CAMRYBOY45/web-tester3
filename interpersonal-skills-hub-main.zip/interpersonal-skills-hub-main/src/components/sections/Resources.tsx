
import React from 'react';
import { Book, Video, Users, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import AnimatedText from '@/components/ui/AnimatedText';
import BlurredCard from '@/components/ui/BlurredCard';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const Resources: React.FC = () => {
  // This is where you can modify the content for each tab
  // ↓↓↓ EDIT THIS SECTION TO CHANGE TAB CONTENT ↓↓↓
  const resourceCategories = {
    books: {
      title: "Recommended Books",
      description: "Dive deep into interpersonal skills with these insightful reads from experts in psychology and communication.",
      icon: <Book size={24} />,
      items: [
        {
          name: "How to Win Friends and Influence People",
          description: "Classic guide by Dale Carnegie on effective communication and relationship building."
        },
        {
          name: "Crucial Conversations: Tools for Talking When Stakes Are High",
          description: "Strategies for handling difficult discussions with confidence and empathy."
        },
        {
          name: "Emotional Intelligence 2.0",
          description: "A practical guide to developing emotional awareness in interactions."
        },
        {
          name: "The Art of Communicating",
          description: "Mindful communication techniques to enhance personal and professional connections."
        }
      ]
    },
    videos: {
      title: "Video Courses",
      description: "Learn through engaging video content that breaks down complex interpersonal concepts into actionable steps.",
      icon: <Video size={24} />,
      items: [
        {
          name: "The Science of Effective Communication",
          description: "Research-based video series on improving verbal and non-verbal communication."
        },
        {
          name: "Body Language Mastery",
          description: "Visual guide to understanding and utilizing non-verbal cues effectively."
        },
        {
          name: "Conflict Resolution Fundamentals",
          description: "Step-by-step video training on resolving disagreements constructively."
        },
        {
          name: "Building Emotional Intelligence",
          description: "Video exercises to develop empathy and emotional awareness."
        }
      ]
    },
    practice: {
      title: "Practice Groups",
      description: "Join communities where you can practice and refine your interpersonal skills in a supportive environment.",
      icon: <Users size={24} />,
      items: [
        {
          name: "Toastmasters International",
          description: "Worldwide organization focused on public speaking and leadership development."
        },
        {
          name: "Local Networking Groups",
          description: "Community-based opportunities to practice social skills in professional settings."
        },
        {
          name: "Interpersonal Skills Workshops",
          description: "Structured group sessions with feedback and guided practice."
        },
        {
          name: "Communication Practice Meetups",
          description: "Casual gatherings designed for practicing conversation and listening skills."
        }
      ]
    },
    skills: {
      title: "Core Interpersonal Skills",
      description: "Master these fundamental abilities to enhance all your interactions and relationships.",
      icon: <Users size={24} />,
      items: [
        {
          name: "Active Listening",
          description: "The art of fully concentrating on a speaker, understanding their message, and thoughtfully responding."
        },
        {
          name: "Empathy Development",
          description: "Learning to understand and share the feelings of another person in different situations."
        },
        {
          name: "Conflict Management",
          description: "Techniques to address disagreements and conflicts in a constructive and positive manner."
        },
        {
          name: "Assertive Communication",
          description: "Expressing your thoughts and feelings clearly while respecting others' perspectives."
        }
      ]
    }
  };
  // ↑↑↑ END OF EDITABLE SECTION ↑↑↑

  const resources = [
    resourceCategories.books,
    resourceCategories.videos,
    resourceCategories.practice,
    resourceCategories.skills
  ];

  return (
    <section id="resources" className="section-padding bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <AnimatedText className="text-center mb-16" animation="slide-up">
          <div className="skill-chip mx-auto mb-4">Learning Materials</div>
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Resources to Develop Your Skills</h2>
          <p className="text-gray-700 max-w-2xl mx-auto">
            Explore these valuable resources to continue developing and refining your interpersonal abilities.
          </p>
        </AnimatedText>
        
        {/* Tabbed Resources Section */}
        <div className="mb-16">
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="mx-auto flex justify-center mb-8">
              <TabsTrigger value="all">All Resources</TabsTrigger>
              <TabsTrigger value="books">Books</TabsTrigger>
              <TabsTrigger value="videos">Videos</TabsTrigger>
              <TabsTrigger value="practice">Practice</TabsTrigger>
              <TabsTrigger value="skills">Skills</TabsTrigger>
            </TabsList>
            
            {/* All Resources Tab */}
            <TabsContent value="all">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {resources.map((resource, index) => (
                  <AnimatedText key={resource.title} delay={200 * index} animation="slide-up">
                    <BlurredCard className="h-full p-8 flex flex-col">
                      <div className="p-3 rounded-full bg-primary/10 text-primary inline-flex mb-6 self-start">
                        {resource.icon}
                      </div>
                      
                      <h3 className="text-xl font-bold mb-3">{resource.title}</h3>
                      <p className="text-gray-700 mb-6">{resource.description}</p>
                      
                      <ul className="space-y-3 mb-6 flex-grow">
                        {resource.items.map((item, itemIndex) => (
                          <li key={itemIndex} className="flex items-start">
                            <span className="text-primary mr-2">•</span>
                            <span>{item.name}</span>
                          </li>
                        ))}
                      </ul>
                      
                      <Button variant="outline" className="group mt-auto">
                        Explore {resource.title}
                        <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={16} />
                      </Button>
                    </BlurredCard>
                  </AnimatedText>
                ))}
              </div>
            </TabsContent>
            
            {/* Individual Category Tabs */}
            {Object.entries(resourceCategories).map(([key, resource]) => (
              <TabsContent key={key} value={key}>
                <div className="max-w-3xl mx-auto">
                  <BlurredCard className="p-8">
                    <div className="flex flex-col md:flex-row items-start gap-6">
                      <div className="p-4 rounded-full bg-primary/10 text-primary">
                        {resource.icon}
                      </div>
                      
                      <div className="w-full">
                        <h3 className="text-2xl font-bold mb-3">{resource.title}</h3>
                        <p className="text-gray-700 mb-6">{resource.description}</p>
                        
                        <ul className="space-y-4 mb-6 w-full">
                          {resource.items.map((item, itemIndex) => (
                            <li key={itemIndex} className="flex flex-col sm:flex-row sm:items-start border-b border-gray-100 pb-3">
                              <div className="flex items-start w-full">
                                <span className="text-primary mr-2 text-xl">•</span>
                                <div className="w-full">
                                  <span className="font-medium">{item.name}</span>
                                  <p className="text-sm text-gray-600 mt-1">
                                    {item.description}
                                  </p>
                                </div>
                              </div>
                            </li>
                          ))}
                        </ul>
                        
                        <Button className="group bg-primary hover:bg-primary/90">
                          Explore All {resource.title}
                          <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={16} />
                        </Button>
                      </div>
                    </div>
                  </BlurredCard>
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>
        
        <AnimatedText animation="slide-up" delay={300}>
          <BlurredCard className="p-10 text-center">
            <h3 className="text-2xl font-bold mb-4">Ready to Transform Your Interactions?</h3>
            <p className="text-gray-700 mb-8 max-w-2xl mx-auto">
              Join our community of learners dedicated to improving their interpersonal skills and achieving greater success in all areas of life.
            </p>
            <Button className="bg-primary hover:bg-primary/90 rounded-full px-8 py-6 text-white">
              Start Your Journey
            </Button>
          </BlurredCard>
        </AnimatedText>
      </div>
    </section>
  );
};

export default Resources;
