
import React from 'react';
import { MessageCircle, Smile, Users, HandshakeIcon, BrainCircuit, ShieldQuestion } from 'lucide-react';
import AnimatedText from '@/components/ui/AnimatedText';
import SkillCard from '@/components/ui/SkillCard';

const KeySkills: React.FC = () => {
  const skills = [
    {
      title: "Active Listening",
      description: "The ability to fully focus on, understand, and remember what others are saying, demonstrating engagement and respect.",
      icon: <MessageCircle size={24} />
    },
    {
      title: "Emotional Intelligence",
      description: "Recognizing your emotions and those of others, using them to guide thinking and behavior, and managing emotions to adapt to environments.",
      icon: <Smile size={24} />
    },
    {
      title: "Teamwork",
      description: "Collaborating effectively with others towards a common goal, leveraging diverse strengths and perspectives.",
      icon: <Users size={24} />
    },
    {
      title: "Conflict Resolution",
      description: "Addressing disagreements constructively to find mutually beneficial solutions while maintaining positive relationships.",
      icon: <HandshakeIcon size={24} />
    },
    {
      title: "Empathy",
      description: "Understanding and sharing the feelings of others, seeing situations from different perspectives to build deeper connections.",
      icon: <BrainCircuit size={24} />
    },
    {
      title: "Assertiveness",
      description: "Expressing thoughts, feelings, and needs clearly and respectfully, standing up for yourself while respecting others.",
      icon: <ShieldQuestion size={24} />
    }
  ];

  return (
    <section id="skills" className="section-padding bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <AnimatedText className="text-center mb-16" animation="slide-up">
          <div className="skill-chip mx-auto mb-4">Core Competencies</div>
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Essential Interpersonal Skills</h2>
          <p className="text-gray-700 max-w-2xl mx-auto">
            These fundamental skills form the foundation of effective human interaction, enabling meaningful connections and successful collaboration.
          </p>
        </AnimatedText>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skills.map((skill, index) => (
            <SkillCard 
              key={skill.title}
              title={skill.title}
              description={skill.description}
              icon={skill.icon}
              delay={200 * index}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default KeySkills;
