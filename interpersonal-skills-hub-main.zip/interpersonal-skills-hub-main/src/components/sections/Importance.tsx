
import React from 'react';
import { CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import AnimatedText from '@/components/ui/AnimatedText';
import BlurredCard from '@/components/ui/BlurredCard';

const Importance: React.FC = () => {
  const benefits = [
    "Build stronger, more authentic relationships",
    "Achieve greater success in your career",
    "Navigate complex social situations with confidence",
    "Resolve conflicts more effectively",
    "Improve team dynamics and collaboration",
    "Enhance leadership capabilities"
  ];

  return (
    <section id="importance" className="section-padding relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 -z-10 overflow-hidden">
        <div className="absolute top-20 left-[10%] w-72 h-72 rounded-full bg-blue-100/30 filter blur-3xl"></div>
        <div className="absolute bottom-20 right-[5%] w-64 h-64 rounded-full bg-purple-100/20 filter blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <AnimatedText animation="slide-right">
            <BlurredCard className="p-10 relative">
              <div className="absolute -top-5 -left-5 w-32 h-32 rounded-full bg-primary/10"></div>
              <div className="relative z-10">
                <div className="skill-chip mb-4">Why It Matters</div>
                <h2 className="text-3xl md:text-4xl font-bold mb-6">The Impact of Strong Interpersonal Skills</h2>
                <p className="text-gray-700 mb-8">
                  In today's interconnected world, your ability to effectively interact with others can determine your success more than technical expertise alone.
                </p>
                
                <ul className="space-y-4 mb-8">
                  {benefits.map((benefit, index) => (
                    <li key={index} className="flex items-start">
                      <CheckCircle className="text-primary shrink-0 mr-3 mt-1" size={20} />
                      <span>{benefit}</span>
                    </li>
                  ))}
                </ul>
                
                <Button className="bg-primary hover:bg-primary/90 rounded-full px-6 py-6">
                  Discover More Benefits
                </Button>
              </div>
            </BlurredCard>
          </AnimatedText>
          
          <AnimatedText animation="slide-left" className="space-y-8">
            <div className="space-y-6">
              <h3 className="text-2xl font-bold">Personal Growth</h3>
              <p className="text-gray-700">
                Strong interpersonal skills enable deeper self-awareness and emotional regulation, fostering personal development and more fulfilling relationships in all areas of life.
              </p>
            </div>
            
            <div className="space-y-6">
              <h3 className="text-2xl font-bold">Professional Success</h3>
              <p className="text-gray-700">
                Studies show that 85% of job success comes from having well-developed soft skills, with interpersonal abilities among the most valued by employers across industries.
              </p>
            </div>
            
            <div className="space-y-6">
              <h3 className="text-2xl font-bold">Social Connection</h3>
              <p className="text-gray-700">
                Humans are inherently social beings. Strong interpersonal skills help us build meaningful connections, establish trust, and create supportive networks.
              </p>
            </div>
            
            <div className="mt-10 p-6 border-l-4 border-primary bg-primary/5 rounded-r-lg">
              <blockquote className="text-lg italic text-gray-700">
                "Technical skills may get you in the door, but interpersonal skills determine how far you'll go."
              </blockquote>
            </div>
          </AnimatedText>
        </div>
      </div>
    </section>
  );
};

export default Importance;
