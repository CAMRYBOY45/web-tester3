
import React, { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header 
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300 py-4 px-6 md:px-10',
        isScrolled ? 'bg-white/80 backdrop-blur-md shadow-sm' : 'bg-transparent'
      )}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <a href="#" className="text-2xl font-bold font-['Playfair_Display']">
          ConnectSkills
        </a>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <a href="#" className="text-gray-800 hover:text-primary transition-colors">Home</a>
          <a href="#skills" className="text-gray-800 hover:text-primary transition-colors">Skills</a>
          <a href="#importance" className="text-gray-800 hover:text-primary transition-colors">Why It Matters</a>
          <a href="#resources" className="text-gray-800 hover:text-primary transition-colors">Resources</a>
          <Button className="bg-primary hover:bg-primary/90 text-white">Get Started</Button>
        </nav>
        
        {/* Mobile Menu Button */}
        <button 
          onClick={toggleMobileMenu}
          className="md:hidden text-gray-800 p-2"
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>
      
      {/* Mobile Menu */}
      <div 
        className={cn(
          'fixed inset-0 bg-white z-40 pt-20 px-6 flex flex-col transition-all duration-300 ease-in-out md:hidden',
          isMobileMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        )}
      >
        <nav className="flex flex-col space-y-8 pt-8">
          <a 
            href="#" 
            className="text-xl text-gray-800 hover:text-primary transition-colors"
            onClick={toggleMobileMenu}
          >
            Home
          </a>
          <a 
            href="#skills" 
            className="text-xl text-gray-800 hover:text-primary transition-colors"
            onClick={toggleMobileMenu}
          >
            Skills
          </a>
          <a 
            href="#importance" 
            className="text-xl text-gray-800 hover:text-primary transition-colors"
            onClick={toggleMobileMenu}
          >
            Why It Matters
          </a>
          <a 
            href="#resources" 
            className="text-xl text-gray-800 hover:text-primary transition-colors"
            onClick={toggleMobileMenu}
          >
            Resources
          </a>
          <Button className="bg-primary hover:bg-primary/90 text-white w-full mt-4">
            Get Started
          </Button>
        </nav>
      </div>
    </header>
  );
};

export default Navbar;
